# Infrastructure cost estimation

Actual cost depends on traffic, model, context length, output tokens, region, retention, and uptime. Do not promise unlimited generation.

| Component | Early-stage option | Main cost driver |
|---|---|---|
| Web | Vercel free/paid tier | Build minutes, bandwidth, functions |
| API | Small container instance | CPU/RAM, uptime, outbound traffic |
| PostgreSQL/Auth/Storage | Supabase plan | Database size, active users, storage, egress |
| Redis | Small managed Redis | Memory and requests |
| Inference | Authorized hosted open-weight API | Input/output tokens, concurrency |
| Self-hosted inference | GPU VM / dedicated GPU | GPU hours, VRAM, idle capacity, bandwidth |

Estimate monthly inference cost as: `requests × average input/output token cost per request`. For self-hosting, estimate `GPU hourly rate × provisioned hours + storage + egress`. Benchmark tokens/second and concurrent sessions using the selected model before committing to capacity.

Recommended controls: per-user daily token budgets, global concurrency caps, queue admission, output limits, model quantization, prompt/result caching only where privacy-safe, batching where supported, and a clear temporary-capacity message. Publish infrastructure spending and contribution totals only after the accounting workflow is verified.
