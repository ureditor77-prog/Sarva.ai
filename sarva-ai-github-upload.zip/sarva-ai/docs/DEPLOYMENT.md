# Deployment guide

## Web on Vercel
1. Push the repository to GitHub.
2. Import the repository in Vercel and set the Root Directory to `apps/web` only if deploying the app as a standalone project. For the monorepo, keep the repository root and set the build command to `cd ../.. && npm install && npm run build:web` only if Vercel's project root is configured to `apps/web`; otherwise use the root `npm run build:web` and output defaults.
3. Set `NEXT_PUBLIC_API_URL`, `NEXT_PUBLIC_SUPABASE_URL`, and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel Environment Variables.
4. Deploy. Configure Supabase Auth Site URL and redirect URLs to the deployed domain.

## Backend
Deploy `backend/api` as a Docker service on a host that supports persistent secrets and outbound HTTPS (for example, a managed container service). Set `DATABASE_URL`, `API_CORS_ORIGINS`, `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `SUPABASE_JWT_SECRET`, and rate-limit settings. Use managed PostgreSQL and Redis in production. Add HTTPS, health checks, log retention, backups, alerting, and a Redis-backed distributed rate limiter before public scale.

## Supabase
Create a project, enable email/password auth, configure email confirmation, and apply `backend/database/migrations/001_initial_schema.sql` in the SQL editor. This migration assumes Supabase's `auth.users` schema. For standalone PostgreSQL, replace the Supabase user foreign keys with your own identity table and implement a production identity provider.

## Android and iOS
Install EAS CLI, configure Expo account/project identifiers, then run `eas build --platform android` or `eas build --platform ios` from `apps/mobile`. Set `EXPO_PUBLIC_API_URL` to the public HTTPS backend URL. iOS builds require Apple Developer account access; Android distribution requires signing configuration. Test on physical devices before store submission.
