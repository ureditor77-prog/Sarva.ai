# SARVA AI API

Base URL: `http://localhost:8000`

## GET /health
Returns API health and whether all required AI provider settings are present.

## GET /v1/models
Returns only the configured model identifier. It does not claim access to proprietary models.

## POST /v1/chat/completions
OpenAI-compatible request shape:

```json
{"messages":[{"role":"user","content":"Explain neural networks simply"}],"stream":true}
```

- `stream: true`: Server-Sent Events (`data: {json}`) ending with `data: [DONE]`.
- `stream: false`: Returns the upstream provider's JSON completion response.
- Optional `Authorization: Bearer <Supabase access token>` is validated when `SUPABASE_JWT_SECRET` is configured.
- Guest requests are currently allowed and rate-limited by source IP. Set a restrictive public quota before public launch.
- Errors use HTTP status codes and a JSON `detail` field before streaming begins. Mid-stream provider failures are emitted as SSE error events.

The configured provider must implement the OpenAI-compatible `/chat/completions` API. Never send provider secrets from the browser or mobile client.
