# Privacy policy and terms — drafting templates only

These are starter outlines, not legal advice and not ready-to-publish policies. Have qualified counsel review them for your operating locations, age groups, vendors, retention, and payment model before launch.

## Privacy policy outline
1. Operator identity and contact details.
2. Information collected: account identifiers, prompts/responses if retained, usage metadata, feedback, and optional contribution records.
3. Purposes and legal basis for processing.
4. AI inference providers and other processors; explain when prompts are sent to them.
5. Retention, deletion, export, and backups.
6. Security practices and limitations.
7. International transfers and subprocessors.
8. User rights, complaint contact, and policy changes.
9. Children's privacy and minimum-age rules.

## Terms outline
1. Eligibility and account responsibilities.
2. Acceptable use and prohibited abuse.
3. AI output limitations and need to verify consequential information.
4. Service availability, capacity limits, queues, and fair-use quotas.
5. Optional contributions, refunds, and payment provider terms.
6. Intellectual property and user content rights.
7. Suspension, termination, liability limitations, and dispute process.
8. Contact and updates.
