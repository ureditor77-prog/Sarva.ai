# Product status and roadmap

## V1 scaffold
- [x] Next.js responsive chat UI with streaming display
- [x] Supabase email/password registration and login UI
- [x] FastAPI OpenAI-compatible model adapter
- [x] Provider credentials remain server-side
- [x] Request validation, basic in-process IP rate limiting, health endpoint
- [x] Docker Compose for local PostgreSQL, Redis and API
- [x] Supabase-oriented SQL schema and RLS policies
- [x] Expo Android/iOS starter chat client (non-streaming)
- [x] PWA manifest and CI workflow

## Required before a public beta
- [ ] Persist conversations/messages through authenticated backend endpoints; add conversation list/search/edit/delete
- [ ] Enforce authenticated usage quotas and reliable token/cost accounting
- [ ] Redis-backed distributed rate limiting and queueing
- [ ] Supabase asymmetric JWT/JWKS validation where applicable
- [ ] Moderation provider/policy and human reporting workflow
- [ ] Secure file upload and private storage
- [ ] Model selector and configured fallback with explicit provider policy
- [ ] Admin RBAC, contribution reporting and payment gateway webhooks
- [ ] Privacy policy and terms reviewed for the target jurisdiction
- [ ] Automated integration tests against a staging Supabase and provider
- [ ] Native auth session management, streaming UI, EAS configuration and store review

## Future modules
Image, video, voice, speech-to-text, PDF, Word, PowerPoint, spreadsheets, web research and coding tools remain unavailable until their providers, safety, queue, storage, and billing/capacity controls are integrated. UI must label them configuration-required or coming soon rather than simulate output.
