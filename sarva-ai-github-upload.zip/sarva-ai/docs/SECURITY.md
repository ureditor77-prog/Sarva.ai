# Security checklist

- [ ] Rotate all provider secrets if they were ever committed; store secrets in deployment secret managers.
- [ ] Enable Supabase email confirmation, strong password policy, and abuse protections.
- [ ] Verify JWT signature and issuer/audience for the exact Supabase signing configuration. Current API verifier supports legacy HS256 only; use Supabase JWKS verification for asymmetric signing keys before production.
- [ ] Replace in-memory rate limiting with Redis-backed distributed limits before multiple API replicas.
- [ ] Add per-account quotas, token/cost accounting, moderation policy, and abuse monitoring.
- [ ] Restrict CORS to exact production domains.
- [ ] Add request-size limits, upload MIME sniffing, malware scanning, signed storage URLs, and private buckets before enabling attachments.
- [ ] Add database backups, point-in-time recovery, retention and deletion workflows.
- [ ] Add admin RBAC, audit log review, and least-privilege service roles before exposing admin tools.
- [ ] Implement and review privacy policy, terms, consent, data export and account deletion flows before public launch.
- [ ] Implement server-side payment order creation and signature-verified webhooks before accepting contributions.
- [ ] Avoid logging prompt content, email addresses, tokens, payment details, or uploaded file contents.

The current V1 deliberately does not accept file uploads or payments. Do not advertise these as available.
