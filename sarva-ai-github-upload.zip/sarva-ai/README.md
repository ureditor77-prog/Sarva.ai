# SARVA AI

**Intelligence for Everyone.** A community-funded, model-agnostic AI platform founded by Meghan Umale.

> This repository is an executable V1 foundation, not a claim that every planned module is production-complete. Core chat can call a real OpenAI-compatible inference endpoint once configured. The web app's auth screens use Supabase Auth. See `docs/PRODUCT_ROADMAP.md` for the exact completion boundary.

## What is included

- Next.js 14 + TypeScript responsive web app with dark/light theme, PWA manifest, Markdown rendering and streaming chat UI.
- Supabase email/password sign-up and sign-in.
- FastAPI backend with OpenAI-compatible streaming/non-streaming chat adapter, server-side provider secrets, request validation, health/model endpoints and basic IP rate limiting.
- Expo starter client for Android and iOS (non-streaming V1 client).
- PostgreSQL/Supabase schema for profiles, conversations, messages, model configs, uploads, usage, feedback, donations and audit logs, with owner-oriented RLS policies.
- Docker Compose for local PostgreSQL, Redis and API; GitHub Actions CI; docs for deployment, security, cost and roadmap.

## Important V1 limitations

Conversation persistence/search/edit/delete are not yet wired into the UI/API; the current web chat lives in the browser session. The SQL schema is prepared for that next implementation. Attachments, payment processing, admin operations, moderation integrations, distributed rate limiting, model selection/fallback, and image/video/voice/document/research tools are not enabled. The native client is a starter, not a store-ready release. Do not launch publicly until the checklist in `docs/SECURITY.md` and roadmap is addressed.

## Prerequisites

- Node.js 20 LTS and npm 10+
- Python 3.12+
- Docker Desktop with Compose
- A Supabase project (email/password enabled)
- An authorized inference provider that exposes an OpenAI-compatible `/chat/completions` endpoint and a model you are entitled to use

## Windows installation (PowerShell)

1. Clone your GitHub repository:

```powershell
git clone https://github.com/YOUR-USERNAME/sarva-ai.git
cd sarva-ai
```

2. Create your local environment file and edit it in Notepad:

```powershell
Copy-Item .env.example .env
notepad .env
```

Set the Supabase URL/anon key, backend Supabase JWT secret (only if using supported HS256 JWT signing), and AI provider base URL, API key and model ID. Never put the AI API key in a `NEXT_PUBLIC_` variable.

3. Install Node dependencies:

```powershell
npm install
```

4. Start local PostgreSQL and Redis:

```powershell
docker compose up -d postgres redis
```

5. Start the API in a second PowerShell window:

```powershell
cd sarva-ai\backend\api
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal and activate again.

6. Start the web app in another PowerShell window from the repository root:

```powershell
cd sarva-ai
npm run dev:web
```

Open `http://localhost:3000`. API docs are at `http://localhost:8000/docs` and health is at `http://localhost:8000/health`.

### Alternative: Docker API

After creating `.env`, run `docker compose up --build`. The Compose API uses the local PostgreSQL and Redis services. The current API does not yet write conversation data to PostgreSQL; the schema is the foundation for the persistence milestone.

## Configure Supabase

1. Create a Supabase project.
2. In Authentication → Providers, enable Email and password. Configure email confirmation and your local/deployed redirect URLs.
3. Copy Project URL and anon/public key into `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. Apply `backend/database/migrations/001_initial_schema.sql` in the Supabase SQL editor. This migration references Supabase's `auth.users` table; it is not a generic vanilla-Postgres migration.
5. If enabling API bearer-token validation, configure a compatible HS256 JWT secret in backend secrets. Supabase projects using asymmetric signing keys need JWKS verification implemented before enabling protected API operations.

## Connect a real open-weight model

You need an inference service/API that you are authorized to use and that supports OpenAI-compatible chat completions. This may be a hosted provider serving an open-weight model or your own inference server. Configure on the backend only:

```dotenv
AI_BASE_URL=https://YOUR-INFERENCE-HOST/v1
AI_API_KEY=YOUR_PRIVATE_PROVIDER_KEY
AI_MODEL=YOUR_PROVIDER_MODEL_ID
AI_TIMEOUT_SECONDS=60
```

`AI_BASE_URL` is the base that already includes `/v1`; the backend appends `/chat/completions`. Restart the API. Check `/health`; `ai_configured` should be true. Send a message in the web chat. A provider error is shown rather than a fabricated response. Do not use proprietary model names unless the matching authorized provider integration is configured.

## Tests and quality checks

From the repository root:

```powershell
npm run typecheck
npm run build:web
```

Backend tests:

```powershell
cd backend\api
py -3.12 -m pip install -r requirements.txt
cd ..\..
py -3.12 -m pytest backend\tests -q
```

CI runs web typecheck/build and backend schema tests on pushes and pull requests.

## Deploy web to Vercel

1. Push this repository to GitHub.
2. Import it into Vercel. Configure the project Root Directory as `apps/web` only if using a standalone app build; because this is a workspace, the simplest reliable option is to keep the repository root and use `npm install` with build command `npm run build:web`.
3. Set `NEXT_PUBLIC_API_URL` to the deployed HTTPS API URL and set the two Supabase public variables.
4. Deploy, then add the Vercel domain to Supabase Auth Site URL and allowed redirect URLs.

## Deploy backend

Build and deploy `backend/api/Dockerfile` using a managed container platform. Supply secrets via the platform's secret manager, not Docker image layers. Set production database/Redis URLs, `API_CORS_ORIGINS` to the exact web origin, and the provider settings. Configure TLS, health checks, backups, monitoring, distributed rate limits and resource quotas. See `docs/DEPLOYMENT.md`.

## Android and iOS builds

From `apps/mobile`:

```powershell
npm install
npx expo start
```

Set `EXPO_PUBLIC_API_URL` to the backend URL (for Android emulator use `http://10.0.2.2:8000`; a physical device needs your computer's LAN IP or a public HTTPS URL). For store builds, configure EAS and run:

```powershell
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android
eas build --platform ios
```

iOS builds require Apple Developer credentials. App store release additionally requires privacy disclosures, signing, device testing, icons/splash assets, and store review.

## Branding

- Name: SARVA AI
- Slogan: Intelligence for Everyone.
- Founder: Meghan Umale
- Instagram: [@meghann_12](https://instagram.com/meghann_12)
- Contact: [meghanumale07@gmail.com](mailto:meghanumale07@gmail.com)

## License
MIT. See `LICENSE`.
