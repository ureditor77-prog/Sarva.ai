import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'SARVA AI — Intelligence for Everyone', description: 'A community-powered AI platform designed to make intelligence accessible to everyone.', manifest: '/manifest.webmanifest', appleWebApp: { capable: true, title: 'SARVA AI', statusBarStyle: 'black-translucent' } };
export const viewport: Viewport = { themeColor: '#0b0b0d', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
