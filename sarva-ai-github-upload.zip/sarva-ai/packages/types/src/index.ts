export type ChatRole = 'system' | 'user' | 'assistant';
export interface ChatMessage { role: ChatRole; content: string; }
export interface ChatCompletionRequest { messages: ChatMessage[]; stream?: boolean; }
export type ModuleStatus = 'available' | 'coming-soon' | 'configuration-required';
