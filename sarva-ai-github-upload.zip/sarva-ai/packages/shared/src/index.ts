export const BRAND = { name: 'SARVA AI', slogan: 'Intelligence for Everyone', founder: 'Meghan Umale' } as const;
export const FUTURE_MODULES = ['image-generation','video-generation','voice','documents','research','coding'] as const;
