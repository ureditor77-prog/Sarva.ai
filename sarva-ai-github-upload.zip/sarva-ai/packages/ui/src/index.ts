// Shared UI package entry point. Web and native components remain platform-specific in V1.
export const SARVA_RADIUS = { card: 24, control: 12 } as const;
