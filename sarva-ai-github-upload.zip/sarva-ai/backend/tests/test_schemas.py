import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "api"))
import pytest
from pydantic import ValidationError
from app.schemas import ChatRequest

def test_valid_chat_request():
    body = ChatRequest(messages=[{"role":"user","content":"Hello"}], stream=True)
    assert body.messages[0].content == "Hello"

def test_requires_user_message():
    with pytest.raises(ValidationError):
        ChatRequest(messages=[{"role":"assistant","content":"Hi"}])

def test_rejects_empty_content():
    with pytest.raises(ValidationError):
        ChatRequest(messages=[{"role":"user","content":""}])
