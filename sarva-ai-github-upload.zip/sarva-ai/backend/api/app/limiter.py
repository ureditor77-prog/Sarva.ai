import time
from collections import defaultdict, deque
from fastapi import HTTPException, Request
from .config import settings

_buckets: dict[str, deque[float]] = defaultdict(deque)

async def enforce_rate_limit(request: Request) -> None:
    # In-memory fallback is suitable only for one process. Use Redis-backed limits for multi-instance production.
    forwarded = request.headers.get("x-forwarded-for", "")
    key = (forwarded.split(",")[0].strip() or (request.client.host if request.client else "unknown"))
    now = time.monotonic(); bucket = _buckets[key]
    while bucket and now - bucket[0] > 60: bucket.popleft()
    if len(bucket) >= settings.rate_limit_per_minute:
        raise HTTPException(status_code=429, detail="Rate limit reached. Please wait a minute and try again.")
    bucket.append(now)
