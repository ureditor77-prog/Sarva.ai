import json
import httpx
from fastapi import HTTPException
from .config import settings

class AIProvider:
    def __init__(self):
        if not settings.ai_base_url or not settings.ai_api_key or not settings.ai_model:
            raise HTTPException(status_code=503, detail="AI provider is not configured. Set AI_BASE_URL, AI_API_KEY and AI_MODEL on the backend.")
        self.url = settings.ai_base_url.rstrip("/") + "/chat/completions"

    def headers(self):
        return {"Authorization": f"Bearer {settings.ai_api_key}", "Content-Type": "application/json"}

    async def stream(self, messages):
        payload = {"model": settings.ai_model, "messages": messages, "stream": True, "temperature": 0.7}
        timeout = httpx.Timeout(settings.ai_timeout_seconds, connect=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            try:
                async with client.stream("POST", self.url, headers=self.headers(), json=payload) as response:
                    if response.status_code >= 400:
                        body = (await response.aread()).decode("utf-8", errors="replace")[:500]
                        raise HTTPException(status_code=502, detail=f"AI provider error ({response.status_code}): {body}")
                    async for line in response.aiter_lines():
                        if line.startswith("data:"):
                            yield line[5:].strip()
            except httpx.TimeoutException:
                raise HTTPException(status_code=504, detail="AI provider timed out. Please retry.")
            except httpx.RequestError:
                raise HTTPException(status_code=502, detail="Could not reach the configured AI provider.")

    async def complete(self, messages):
        payload = {"model": settings.ai_model, "messages": messages, "stream": False, "temperature": 0.7}
        timeout = httpx.Timeout(settings.ai_timeout_seconds, connect=10.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            try:
                response = await client.post(self.url, headers=self.headers(), json=payload)
                response.raise_for_status()
                return response.json()
            except httpx.TimeoutException:
                raise HTTPException(status_code=504, detail="AI provider timed out.")
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=502, detail=f"AI provider returned HTTP {exc.response.status_code}.")
            except (httpx.RequestError, json.JSONDecodeError):
                raise HTTPException(status_code=502, detail="Could not complete the AI request.")
