from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    api_cors_origins: str = "http://localhost:3000"
    database_url: str = "postgresql+asyncpg://sarva:sarva_dev_password@localhost:5432/sarva"
    redis_url: str = "redis://localhost:6379/0"
    supabase_jwt_secret: str = ""
    ai_base_url: str = ""
    ai_api_key: str = ""
    ai_model: str = ""
    ai_fallback_model: str = ""
    ai_timeout_seconds: int = 60
    max_input_chars: int = 20000
    rate_limit_per_minute: int = 20
    model_config = SettingsConfigDict(env_file=Path(__file__).resolve().parents[3] / ".env", extra="ignore")

settings = Settings()
