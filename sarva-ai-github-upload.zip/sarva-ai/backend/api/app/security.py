import jwt
from fastapi import Header, HTTPException
from .config import settings

async def optional_user(authorization: str | None = Header(default=None)) -> str | None:
    """Validate Supabase HS256 access tokens when configured; otherwise chat is guest-limited."""
    if not authorization:
        return None
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")
    if not settings.supabase_jwt_secret:
        raise HTTPException(status_code=503, detail="Authentication verification is not configured on the API")
    token = authorization[7:]
    try:
        payload = jwt.decode(token, settings.supabase_jwt_secret, algorithms=["HS256"], options={"require": ["exp", "sub"]})
        if payload.get("role") not in ("authenticated", "service_role"):
            raise ValueError("Unexpected token role")
        return str(payload["sub"])
    except (jwt.PyJWTError, ValueError, KeyError):
        raise HTTPException(status_code=401, detail="Invalid or expired access token")
