from typing import Literal
from pydantic import BaseModel, Field, field_validator

class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1, max_length=20000)

class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=40)
    stream: bool = True

    @field_validator("messages")
    @classmethod
    def require_user_message(cls, messages):
        if not any(m.role == "user" for m in messages):
            raise ValueError("At least one user message is required")
        return messages
