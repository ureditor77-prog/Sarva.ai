import json
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from .config import settings
from .schemas import ChatRequest
from .security import optional_user
from .limiter import enforce_rate_limit
from .orchestrator import AIProvider

app = FastAPI(title="SARVA AI API", version="0.1.0", description="Model-agnostic API for SARVA AI.")
origins = [o.strip() for o in settings.api_cors_origins.split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])

@app.get("/health")
async def health():
    return {"status": "ok", "service": "sarva-ai-api", "ai_configured": bool(settings.ai_base_url and settings.ai_api_key and settings.ai_model)}

@app.get("/v1/models")
async def models():
    return {"data": ([{"id": settings.ai_model, "object": "model", "owned_by": "configured-provider"}] if settings.ai_model else []), "note": "Only configured model identifiers are advertised."}

@app.post("/v1/chat/completions")
async def chat(body: ChatRequest, request: Request, user_id: str | None = Depends(optional_user)):
    await enforce_rate_limit(request)
    if sum(len(m.content) for m in body.messages) > settings.max_input_chars:
        raise HTTPException(status_code=413, detail="Conversation input exceeds the configured limit.")
    messages = [m.model_dump() for m in body.messages]
    provider = AIProvider()
    if not body.stream:
        result = await provider.complete(messages)
        return result
    async def events():
        try:
            async for event in provider.stream(messages):
                if event == "[DONE]":
                    yield "data: [DONE]\n\n"; return
                # Validate and re-emit provider SSE payload; malformed provider lines are ignored.
                try:
                    json.loads(event)
                    yield f"data: {event}\n\n"
                except json.JSONDecodeError:
                    continue
            yield "data: [DONE]\n\n"
        except HTTPException as exc:
            payload = json.dumps({"error": {"message": exc.detail}})
            yield f"data: {payload}\n\n"
            yield "data: [DONE]\n\n"
    return StreamingResponse(events(), media_type="text/event-stream", headers={"Cache-Control":"no-cache", "X-Accel-Buffering":"no"})
