-- Apply after creating a Supabase project or PostgreSQL database.
create extension if not exists pgcrypto;
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'New conversation',
  model_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('system','user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create table if not exists model_configurations (
  id uuid primary key default gen_random_uuid(), model_id text unique not null,
  provider text not null, endpoint text, enabled boolean not null default false,
  is_default boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists file_uploads (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null, filename text not null, mime_type text not null, size_bytes bigint not null check(size_bytes > 0),
  created_at timestamptz not null default now()
);
create table if not exists usage_events (
  id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete set null,
  model_id text, input_tokens bigint not null default 0, output_tokens bigint not null default 0,
  status text not null, created_at timestamptz not null default now()
);
create table if not exists feedback (
  id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete set null,
  category text not null, message text not null, created_at timestamptz not null default now()
);
create table if not exists donations (
  id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete set null,
  provider text not null, provider_payment_id text unique, amount_minor bigint not null check(amount_minor > 0),
  currency char(3) not null default 'INR', status text not null, created_at timestamptz not null default now()
);
create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(), actor_id uuid references auth.users(id) on delete set null,
  action text not null, resource_type text, resource_id text, metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists conversations_user_updated_idx on conversations(user_id, updated_at desc);
create index if not exists messages_conversation_created_idx on messages(conversation_id, created_at);
create index if not exists usage_user_created_idx on usage_events(user_id, created_at desc);
-- Row Level Security: users can only access their own private records.
alter table profiles enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table file_uploads enable row level security;
alter table usage_events enable row level security;
alter table feedback enable row level security;
alter table donations enable row level security;
alter table audit_logs enable row level security;
create policy "profile owner" on profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "conversation owner" on conversations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "message owner" on messages for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "file owner" on file_uploads for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "usage owner read" on usage_events for select using (auth.uid() = user_id);
create policy "feedback owner insert" on feedback for insert with check (auth.uid() = user_id);
create policy "donation owner read" on donations for select using (auth.uid() = user_id);
-- No client policies for audit_logs or model_configurations: service/admin access only.
